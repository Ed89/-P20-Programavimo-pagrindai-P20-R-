import java.util.Scanner;

public class uzd_01 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Ivesti sk.: ");
        int numb = reader.nextInt();
        int count = 0;
        System.out.print("Ivesti sk.: ");
        int numb2 = reader.nextInt();

        for (int i = numb; i <= numb2; i++) {
            if (i % inter(i) == 0) {
                System.out.println(i+" - "+inter(i));
                count++;
            }

        }
        System.out.println(count);
        //   System.out.println(inter(numb));


    }

    private static int inter(int numb) {
        int skaicSum = 0;

        while (numb > 0) {
            skaicSum = skaicSum + (numb % 10);
            numb /= 10;
        }
        return skaicSum;
    }
}
