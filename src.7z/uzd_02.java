import java.util.Scanner;

public class uzd_02 {
    public static void main(String[] args) {

        int count = 0;
        for (int i = 36; i <= 120; i++) {

                count += inter(i);


        }
        System.out.println(count);



    }

    private static int inter(int numb) {
        int skaicSum = 0;

        while (numb > 0) {
            skaicSum = skaicSum + (numb % 10);
            numb /= 10;
        }
        return skaicSum;
    }

}
