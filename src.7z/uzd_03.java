public class uzd_03 {
    public static void main(String[] args) {

        int count = 0;
        String zero = "0";

        for (int i = 36; i <= 120; i++) {
            count = revers(i);
            int a = Integer.toString(count).length();
            String zero_repeat = zero.repeat(a);

            if (i % 10 == 0) {

                if (a == 1 && i >= 100) {
                    a++;
                    System.out.println(i + " " + (zero.repeat(a)) + count + " " + a + " a == 1 && i>=100");
                } else {
                    System.out.println(i + " " + zero + count + " " + a + " a == 1 else ");
                }
            } else
                System.out.println(i + " " + count + " else");
        }
    }


    private static int revers(int num) {
        int reversed = 0;
        while (num != 0) {
            int digit = num % 10;
            reversed = reversed * 10 + digit;
            num /= 10;
        }
        return reversed;
    }
}
