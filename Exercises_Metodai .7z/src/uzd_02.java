public class uzd_02 {
    public static void main(String[] args) {
        int a=25;
        int b=45;
        int c=65;
        float z=average(a,b,c);
        System.out.println("The average value is "+z);
    }

    private static int average(int a, int b, int c) {
       int result = (a+b+c)/3;
       return result;

    }
}
