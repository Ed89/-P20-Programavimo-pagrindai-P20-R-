import java.util.Scanner;

public class uzd_09 {
    public static void main(String[] args) {
//        Scanner pints = new Scanner(System.in);
//        System.out.println("Input side size: ");
//        int a = pints.nextInt();
        int a=3;
        int b=17;
        printStars(a,b);
        //pints.close();
    }

    private static void printStars(int a, int b) {
        for (int i=1;i<=a; i++){
            System.out.print("*");
            printRectangle(b);
        }
        System.out.println("");
    }

    private static void printRectangle(int a) {
        for (int i=1;i<=a; i++){
            System.out.print("*");

        }
        System.out.println("");
    }
}
