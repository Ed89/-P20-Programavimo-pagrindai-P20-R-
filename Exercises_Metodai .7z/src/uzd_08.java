import java.util.Scanner;

public class uzd_08 {
    public static void main(String[] args) {
       Scanner pints = new Scanner(System.in);
       System.out.println("Input side size: ");
       int a = pints.nextInt();
        printSquare(a);
        pints.close();
    }

    private static void printStars(int a) {
        for (int i=1;i<=a; i++){
            System.out.print("*");

        }
        System.out.println("");
    }

    private static void printSquare(int a) {
        for (int i=1;i<=a; i++){
            System.out.print("*");
                printStars(a);
        }
        System.out.println("");
    }
}
