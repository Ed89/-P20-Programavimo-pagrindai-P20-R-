import java.util.Scanner;

public class uzd_04 {
    public static void main(String[] args) {
        System.out.println("Ivesti metus: ");
        Scanner myObj = new Scanner(System.in);
        int year = myObj.nextInt();

        boolean lYear = leapYear(year);
        if (lYear)
            System.out.println(lYear );
        else
            System.out.println(lYear );

    }

    private static boolean leapYear(int year) {
        boolean rezult =false;

        // if the year is divided by 4
        if (year % 4 == 0) {
            // if the year is century
            if (year % 100 == 0) {
                // if year is divided by 400
                // then it is a leap year
                if (year % 400 == 0)
                    rezult = true;
                else
                    rezult = false;
            }

            // if the year is not century
            else
                rezult = true;
        }

        else
            rezult = false;




        return rezult;
    }
}

