import java.util.Scanner;

public class uzd_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input side size: ");
        int a = scanner.nextInt();
        printStars(a);
        scanner.close();


    }

    private static void printStars(int a) {
        for (int i=0;i<a; i++){
        System.out.print("*");
        }
        System.out.println("");
    }


}
