public class uzd_01 {
    public static void main(String[] args) {
int a= 25;
int b=37;
int c=29;
        int z = min(a,b,c);
        System.out.println(" The smallest value is "+z);
    }

    private static int min(int a, int b, int c) {
    int result;
    if((a < b)&&(a<c))
        result = a;
    else if ((b<a)&&(b<c))
        result =b;
    else result =c;
    return result;
    }
}
