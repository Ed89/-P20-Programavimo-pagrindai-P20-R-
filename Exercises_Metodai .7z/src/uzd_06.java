public class uzd_06 {
    public static void main(String[] args) {
        int a=5;
        int b=6;
       double rez =  pentagon(a, b);
        System.out.println("The area of the pentagon is "+ String.format("%.3f", rez));
    }

    private static double pentagon(int a, int b) {
        double S=0;
        S=(b*b*a)/(4*Math.tan(Math.PI/a));

        return S;
    }
}
