public class uzd_05 {
    public static void main(String[] args) {
        int a =10;
        int b=15;
        int c=20;
        double rez = triangle(a,b,c);
        System.out.println("The area of triange is " + String.format("%.2f", rez));
    }

    private static double triangle(int a, int b, int c) {
        double S;
        float p = (float)(a+b+c)/2;
        S=Math.sqrt(p*(p-a)*(p-b)*(p-c));

        return S;
    }
}
