public class uzd_03 {
    public static void main(String[] args) {

    }
}
